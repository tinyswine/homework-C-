#include <stdio.h>

void print(double i)
{
	printf("%f\n", i * 2);
}