#include <stdio.h>

int main()
{
	double i = 4.0;
	print(i);
}