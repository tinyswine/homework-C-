#include<stdio.h>

int main()
{
	int married = 1;
	printf(married == 0 ? "Someone is unmarried" : "Someone is married\n");
}