#include<stdio.h>

int main()
{
	printf("My first C-program\nis a fact!\nGood, isn't it?");
}