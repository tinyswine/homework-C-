#include<stdio.h>

int main()
{
	int i = 5;
	printf("%d\n", i--); //5
	i = 5;
	printf("%d\n", --i); //4
}