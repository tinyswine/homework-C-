#include<stdio.h>

int main()
{
	int number = 5, n = 4;
	printf("%d\n", number << n);
}