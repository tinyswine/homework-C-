#ifndef DEFS
#define DEFS
#include "Defs.h"
#endif // !DEFS

int main()
{
	double a = 3.0, b = -5.0, c = 9.0;
	PRINT1(MAX2(a, b));
	PRINT1(MAX3(a, b, c));
}