
#ifndef DEFS
#define DEFS
#include "Defs.h"
#endif // !DEFS

int main()
{
	double a = 5, b = -2;
	PRINT1(a);
	PRINT2(a, b);
}
